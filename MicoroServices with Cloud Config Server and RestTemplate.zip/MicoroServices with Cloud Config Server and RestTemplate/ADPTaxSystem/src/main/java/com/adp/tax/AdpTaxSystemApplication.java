package com.adp.tax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdpTaxSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdpTaxSystemApplication.class, args);
	}

}
