package com.honeywell;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class HoneywellEmployeeSalaryService {

	@GetMapping(path="/honeywell/{eno}/{name}/{salary}")
	public Employee employeeSalaryCal(
			@PathVariable("eno") Integer eno,
			@PathVariable("name") String name,
			@PathVariable("salary") Double salary) {
		
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("eno", eno);
		hashMap.put("salary", salary);
	
		RestTemplate template = new RestTemplate();
		String url = "http://localhost:6001/adptax/{eno}/{salary}";
		ResponseEntity<Employee> entity = template.getForEntity(url,Employee.class,hashMap);
		Employee employee = entity.getBody();
		employee.setName(name);
		return employee;
	}
}






























