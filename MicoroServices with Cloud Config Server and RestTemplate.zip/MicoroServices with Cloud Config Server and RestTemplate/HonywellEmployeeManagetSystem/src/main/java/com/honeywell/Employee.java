package com.honeywell;

public class Employee {

	private Integer eno;
	private String name;
	private Double taxableAmount;
	private Double salaryAfterTax;
	
	public Employee() {
		super();
	}
	public Employee(Integer eno, String name, Double taxableAmount, Double salaryAfterTax) {
		super();
		this.eno = eno;
		this.name = name;
		this.taxableAmount = taxableAmount;
		this.salaryAfterTax = salaryAfterTax;
	}
	public Integer getEno() {
		return eno;
	}
	public void setEno(Integer eno) {
		this.eno = eno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getTaxableAmount() {
		return taxableAmount;
	}
	public void setTaxableAmount(Double taxableAmount) {
		this.taxableAmount = taxableAmount;
	}
	public Double getSalaryAfterTax() {
		return salaryAfterTax;
	}
	public void setSalaryAfterTax(Double salaryAfterTax) {
		this.salaryAfterTax = salaryAfterTax;
	}
	
	
}
