package com.honeywell;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name="ADPTaxSystem",url="http://localhost:6001")
public interface ADPEmployeeTaxServicepProxy {

	@GetMapping(path="/adptax/{eno}/{salary}")
	public Employee calTax(@PathVariable("eno") Integer eno,
			@PathVariable("salary") Double salary);

}
