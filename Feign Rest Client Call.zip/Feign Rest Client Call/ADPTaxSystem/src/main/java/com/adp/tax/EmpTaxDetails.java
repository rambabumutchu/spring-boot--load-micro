package com.adp.tax;

public class EmpTaxDetails {

	private Integer eno;
	private Double taxableAmount;
	private Double salaryAfterTax;
	
	public EmpTaxDetails() {
		super();
	}
	
	public EmpTaxDetails(Integer eno, Double taxableAmount, Double salaryAfterTax) {
		super();
		this.eno = eno;
		this.taxableAmount = taxableAmount;
		this.salaryAfterTax = salaryAfterTax;
	}
	public Integer getEno() {
		return eno;
	}
	public void setEno(Integer eno) {
		this.eno = eno;
	}
	public Double getTaxableAmount() {
		return taxableAmount;
	}
	public void setTaxableAmount(Double taxableAmount) {
		this.taxableAmount = taxableAmount;
	}
	public Double getSalaryAfterTax() {
		return salaryAfterTax;
	}
	public void setSalaryAfterTax(Double salaryAfterTax) {
		this.salaryAfterTax = salaryAfterTax;
	}
	
	
}
