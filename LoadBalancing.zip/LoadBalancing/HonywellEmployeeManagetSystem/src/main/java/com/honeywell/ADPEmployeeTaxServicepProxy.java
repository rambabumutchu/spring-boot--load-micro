package com.honeywell;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RibbonClient(name="ADPTaxSystem")
@FeignClient(name="ADPTaxSystem")
public interface ADPEmployeeTaxServicepProxy {

	@GetMapping(path="/adptax/{eno}/{salary}")
	public Employee calTax(@PathVariable("eno") Integer eno,
			@PathVariable("salary") Double salary);

}
