package com.honeywell;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HoneywellEmployeeSalaryService {
	
	@Autowired
	private ADPEmployeeTaxServicepProxy proxy;

	@GetMapping(path="/honeywell/{eno}/{name}/{salary}")
	public Employee employeeSalaryCal(
			@PathVariable("eno") Integer eno,
			@PathVariable("name") String name,
			@PathVariable("salary") Double salary) {
		
		Employee employee = proxy.calTax(eno, salary);
		
		employee.setName(name);
		return employee;
	}
}






























